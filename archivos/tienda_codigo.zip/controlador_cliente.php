<?php
require 'conexion.php';  // Incluir la conexión a la base de datos
require 'modelo_cliente.php';

$cliente_modelo = new ModeloCliente($conexion);  // Instanciar el modelo de cliente

// Verificar si se ha enviado una solicitud POST para añadir o eliminar un cliente
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['añadir_cliente'])) {
        // Añadir un nuevo cliente
        $cliente_modelo->añadirCliente($_POST['nombre'], $_POST['apellido'], $_POST['email'], $_POST['telefono'], $_POST['direccion']);
    } elseif (isset($_POST['eliminar_cliente'])) {
        // Eliminar un cliente
        $cliente_modelo->eliminarCliente($_POST['id_cliente']);
    }
}

// Obtener la lista de todos los clientes
$clientes = $cliente_modelo->obtenerClientes();

// Incluir la vista de clientes
require 'vista_cliente.php';
?>
