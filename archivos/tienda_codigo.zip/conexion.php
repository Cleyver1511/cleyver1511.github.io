<?php
$host = 'localhost';
$usuario = 'root';
$password = '';
$base_datos = 'tienda_online';

// Crear la conexión a la base de datos
$conexion = new mysqli($host, $usuario, $password, $base_datos);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
}
?>
