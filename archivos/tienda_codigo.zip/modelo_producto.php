<?php
class ModeloProducto {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    public function obtenerProductos() {
        $query = "SELECT * FROM Productos";
        $resultado = $this->conexion->query($query);
        return $resultado->fetch_all(MYSQLI_ASSOC);
    }

    public function obtenerDetallesPedido() {
        $query = "SELECT p.nombre, d.id_pedido, p.precio, d.cantidad, d.precio_unitario, pe.fecha_pedido, pe.estado
                  FROM Detalles_Pedido d
                  JOIN Pedidos pe ON d.id_pedido = pe.id_pedido
                  JOIN Productos p ON d.id_producto = p.id_producto";
        $resultado = $this->conexion->query($query);
        return $resultado->fetch_all(MYSQLI_ASSOC);
    }

    public function añadirProducto($nombre, $descripcion, $precio, $stock, $categoria) {
        $query = "INSERT INTO Productos (nombre, descripcion, precio, stock, categoria) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conexion->prepare($query);
        $stmt->bind_param('ssdiss', $nombre, $descripcion, $precio, $stock, $categoria);
        $stmt->execute();
    }

    public function eliminarProducto($id_producto) {
        $query = "DELETE FROM Productos WHERE id_producto = ?";
        $stmt = $this->conexion->prepare($query);
        $stmt->bind_param('i', $id_producto);
        $stmt->execute();
    }
}
?>
