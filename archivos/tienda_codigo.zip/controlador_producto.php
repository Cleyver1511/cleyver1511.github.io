<?php
include 'conexion.php';
include 'modelo_producto.php';

// Crear instancias de los modelos
$producto_modelo = new ModeloProducto($conexion);

// Obtener todos los productos
$productos = $producto_modelo->obtenerProductos();

// Obtener todos los detalles de pedidos para cada producto
$detalles_pedido = $producto_modelo->obtenerDetallesPedido(); // Asegúrate de tener este método en el modelo

// Comprobar si se ha enviado un formulario para añadir o eliminar productos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['añadir_producto'])) {
        // Lógica para añadir un nuevo producto
        $producto_modelo->añadirProducto($_POST['nombre'], $_POST['descripcion'], $_POST['precio'], $_POST['stock'], $_POST['categoria']);
        header('Location: vista_producto.php');
        exit();
    }

    if (isset($_POST['eliminar_producto'])) {
        // Lógica para eliminar un producto
        $producto_modelo->eliminarProducto($_POST['id_producto']);
        header('Location: vista_producto.php');
        exit();
    }
}

include 'vista_producto.php';
?>
