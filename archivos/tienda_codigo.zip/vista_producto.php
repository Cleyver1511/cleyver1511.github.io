<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 28px;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            background-color: white;
            padding: 20px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .form-container {
            width: 100%;
            margin-bottom: 20px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .delete-btn {
            background-color: #f44336;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        .back-btn {
            background-color: #333;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            margin-bottom: 20px;
        }

        .back-btn:hover {
            background-color: #555;
        }

    </style>
</head>
<body>

    <div class="container">
        <h1>Gestión de Productos</h1>

        <!-- Botón para volver al menú principal -->
        <a href="menu_principal.php" class="back-btn">Volver al Menú Principal</a>

        <!-- Tabla para listar los productos -->
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Categoría</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productos as $producto): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($producto['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                        <td><?php echo htmlspecialchars($producto['precio']); ?></td>
                        <td><?php echo htmlspecialchars($producto['stock']); ?></td>
                        <td><?php echo htmlspecialchars($producto['categoria']); ?></td>
                        <td>
                            <!-- Botón para eliminar producto -->
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="id_producto" value="<?php echo htmlspecialchars($producto['id_producto']); ?>">
                                <button type="submit" name="eliminar_producto" class="delete-btn">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Mostrar pedidos relacionados con el producto -->
        <h2>Pedidos Relacionados con los Productos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Fecha Pedido</th>
                    <th>Estado</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($detalles_pedido)): ?>
                    <?php foreach ($detalles_pedido as $detalle): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($detalle['id_pedido']); ?></td>
                            <td><?php echo htmlspecialchars($detalle['fecha_pedido']); ?></td>
                            <td><?php echo htmlspecialchars($detalle['estado']); ?></td>
                            <td><?php echo htmlspecialchars($detalle['cantidad']); ?></td>
                            <td><?php echo htmlspecialchars($detalle['precio_unitario']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No hay detalles de pedidos disponibles.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Formulario para añadir un nuevo producto -->
        <h2>Añadir Nuevo Producto</h2>
        <div class="form-container">
            <form method="post">
                <input type="text" name="nombre" placeholder="Nombre" required>
                <textarea name="descripcion" placeholder="Descripción" required></textarea>
                <input type="number" step="0.01" name="precio" placeholder="Precio" required>
                <input type="number" name="stock" placeholder="Stock" required>
                <input type="text" name="categoria" placeholder="Categoría" required>
                <button type="submit" name="añadir_producto">Añadir Producto</button>
            </form>
        </div>
    </div>

</body>
</html>
