<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Principal</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            color: #333;
            font-size: 36px;
            margin-bottom: 20px;
        }

        .menu-container {
            background-color: white;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 10px;
            width: 300px;
            text-align: center;
        }

        .menu-container h2 {
            color: #444;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .menu-item {
            display: block;
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            margin: 10px 0;
            text-decoration: none;
            font-size: 18px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .menu-item:hover {
            background-color: #45a049;
        }

        .menu-item:active {
            background-color: #388E3C;
        }

        .menu-footer {
            margin-top: 20px;
            color: #666;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <div class="menu-container">
        <h1>Menú Principal</h1>

        <h2>Gestión de:</h2>

        <!-- Opciones del menú -->
        <a href="controlador_cliente.php" class="menu-item">Gestionar Clientes</a>
        <a href="controlador_producto.php" class="menu-item">Gestionar Productos</a>

        <div class="menu-footer">
            <p>© 2024 Tu Tienda Online</p>
        </div>
    </div>

</body>
</html>
