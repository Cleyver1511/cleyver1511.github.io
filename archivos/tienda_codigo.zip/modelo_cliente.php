<?php
class ModeloCliente {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    // Obtener todos los clientes
    public function obtenerClientes() {
        $sql = "SELECT * FROM Clientes";
        $resultado = $this->conexion->query($sql);
        return $resultado->fetch_all(MYSQLI_ASSOC);
    }

    // Añadir un nuevo cliente
    public function añadirCliente($nombre, $apellido, $email, $telefono, $direccion) {
        $sql = "INSERT INTO Clientes (nombre, apellido, email, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("sssss", $nombre, $apellido, $email, $telefono, $direccion);
        return $stmt->execute();
    }

    // Eliminar un cliente
    public function eliminarCliente($id_cliente) {
        $sql = "DELETE FROM Clientes WHERE id_cliente = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id_cliente);
        return $stmt->execute();
    }
}
?>
